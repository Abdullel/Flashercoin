BOT_TOKEN = "TON_TOKEN_ICI"  # Remplace par le token donné par BotFather
CHANNEL_USERNAME = "@NomDeTaChaine"  # Exemple : "@airdropchannel"
