import csv
import os
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes
from config import BOT_TOKEN, CHANNEL_USERNAME

DATA_FILE = "data/users.csv"

# Création du fichier CSV s'il n'existe pas
os.makedirs("data", exist_ok=True)
if not os.path.exists(DATA_FILE):
    with open(DATA_FILE, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["UserID", "Username", "Wallet"])

# Fonction: vérifier si le user est abonné à la chaîne
async def is_subscribed(user_id, context):
    try:
        member = await context.bot.get_chat_member(CHANNEL_USERNAME, user_id)
        return member.status in ["member", "administrator", "creator"]
    except:
        return False

# /start
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not await is_subscribed(user.id, context):
        await update.message.reply_text(
            f"👋 Salut {user.first_name} !\n"
            f"Pour participer à l’airdrop, tu dois d'abord rejoindre notre chaîne : {CHANNEL_USERNAME}"
        )
        return

    await update.message.reply_text(
        f"🎉 Bienvenue à l'airdrop, {user.first_name}!\n\n"
        "✅ Tu as bien rejoint la chaîne.\n"
        "📥 Envoie ton adresse crypto (BEP20/ERC20) pour recevoir tes tokens."
    )

# Enregistrement de l'adresse crypto
async def handle_wallet(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    wallet = update.message.text

    if len(wallet) < 20:
        await update.message.reply_text("❌ Adresse invalide. Réessaye.")
        return

    with open(DATA_FILE, "a", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([user.id, user.username or "None", wallet])

    await update.message.reply_text("✅ Ton adresse a bien été enregistrée. Merci de ta participation !")

def main():
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_wallet))
    print("✅ Bot en marche...")
    app.run_polling()

if __name__ == "__main__":
    main()
